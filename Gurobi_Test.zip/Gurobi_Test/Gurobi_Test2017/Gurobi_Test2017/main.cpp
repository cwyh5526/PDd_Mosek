//#include "UI.h"
//#include "FullTest_p.h"
//
//int main(int argc, const char *argv[])
//{
//	tet sTet; //static tetrahedron
//	tet rTet; //rest pose tetrahedron
//	tet pTet; //deformed pose tetrahedron
//	double totalOptTime;
//	double minOptValue;
//	int minOptIndex;
//
//
//
//	init(&sTet, &rTet, &pTet);
//
//	resolvePenetration(sTet, rTet, &pTet, &minOptValue, &minOptIndex, &totalOptTime);
//
//	printResult(sTet, rTet, pTet, minOptValue, minOptIndex, totalOptTime);
//
//	return 0;
//}